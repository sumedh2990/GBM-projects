package com.pmscheme.model;

import java.util.List;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Request {

	private String masterPolicyNumber;
	private String id;

	@NotEmpty(message = "{request.field.customerId} {request.customerId.empty}")
	@Pattern(regexp = "^[1-9][0-9]{20}$", message = "{request.customerId.invalid} {request.field.customerId}")
	private String customerId;

	@NotEmpty(message = "{request.field.customerName} {request.customerName.empty}")
	@Size(min = 3, message = "{request.field.customerName} {request.customerName.minlength}")
	@Size(max = 100, message = "{request.field.customerName} {request.customerName.maxlength}")
	@Pattern(regexp = "^[a-zA-Z\\s',]+$", message = "{request.customerName.invalid}")
	private String customerName;

	@NotEmpty(message = "{request.field.fatherName} {request.fatherName.empty}")
	@Size(min = 3, message = "{request.field.fatherName} {request.fatherName.minlength}")
	@Size(max = 100, message = "{request.field.fatherName} {request.fatherName.maxlength}")
	@Pattern(regexp = "^[a-zA-Z\\s',]+$", message = "{request.fatherName.invalid}")
	private String fatherName;

	@NotEmpty(message = "{request.field.address} {request.address.empty}")
	@Size(min = 3, message = "{request.field.address} {request.address.minlength}")
	@Size(max = 180, message = "{request.field.address} {request.address.maxlength}")
	// @Pattern(regexp="^[a-zA-Z\\s',#&()]+$",
	// message="{request.fatherName.invalid}")
	private String address1;

	private String address2;

	private String address3;

	@NotEmpty(message = "{request.field.city} {request.address.empty}")
	@Size(min = 3, message = "{request.field.city} {request.address.minlength}")
	@Size(max = 180, message = "{request.field.city} {request.address.maxlength}")
	private String city;

	private String district;

	@NotEmpty(message = "{request.field.state} {request.state.empty}")
	@Size(min = 2, message = "{request.field.state} {request.state.minlength}")
	@Size(max = 2, message = "{request.field.state} {request.state.maxlength}")
	private String state;

	@NotEmpty(message = "{request.field.pin} {request.pin.empty}")
	@Size(min = 6, message = "{request.field.pin} {request.pin.minlength}")
	@Size(max = 6, message = "{request.field.pin} {request.pin.maxlength}")
	private String pin;

	private String dob;

	@NotEmpty(message = "{request.field.gender} {request.gender.empty}")
	@Size(min = 1, message = "{request.field.gender} {request.gender.minlength}")
	@Size(max = 1, message = "{request.field.gender} {request.gender.maxlength}")
	@Pattern(regexp = "^[MFT]$", message = "{request.gender.invalid} {request.field.gender}")
	private String gender;

	@NotEmpty(message = "{request.field.gender} {request.mobileNo.empty}")
	private String mobileNo;

	@NotEmpty(message = "{request.field.gender} {request.email.empty}")
	@Pattern(regexp = "^(\\s{0}|[_a-zA-Z0-9-]+(\\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*(\\.[a-zA-Z]{2,4}))$", message = "{request.email.invalid}")
	private String emailId;

	@NotEmpty(message = "{request.field.anydisability} {request.anydisability.empty}")
	@Pattern(regexp = "^(Y|N)$", message = "{request.anydisability.invalid}")
	private String anyDisability;

	private String disabilityRemarks;
	private String dateOfApplication;
	private String sourcingCode;

	@NotEmpty(message = "{request.field.premiumAmount} {request.premiumAmount.empty}")
	private String premiumAmount;

	private String branchCategory;

	@NotEmpty(message = "{request.field.accountNumber} {request.accountNumber.empty}")
	private String accountNo;

	@NotEmpty(message = "{request.field.branchCode} {request.branchCode.empty}")
	private String branchCode;

	@NotEmpty(message = "{request.field.branchName} {request.branchName.empty}")
	private String branchName;

	@NotEmpty(message = "{request.field.ifsCode} {request.ifsCode.empty}")
	private String ifsCode;

	private List<KycDetail> kycDetails;

	@NotEmpty(message = "{request.field.nomieeName} {request.nomieeName.empty}")
	private String nomineeName;

	@NotEmpty(message = "{request.field.nomineeRelationWithSubscriber} {request.nomineeRelationWithSubscriber.empty}")
	private String nomineeRelationWithSubscriber;

	private String isRegistrationReviewed;
	

	private String nomineeDob;
	private String nomineeAge;
	private String nomineeAddress;
	private String nomineeMobileNumber;
	private String nomineeEmailId;
	private String guardianName;
	private String relationshipWithGuardian;
	private String guardianMobileNo;
	private String guardianEmailId;
	private String formBase64;
	private String schemeType;
	private String registrationBranchCode;
	private String kycDocumentSubmittedByCustomer;
	private String kycIDNumberOfSubscriber;
	private String createdBy;
	private String createdOn;
	private String modifyBy;
	private String modifyOn;
	private String channel;
	private String isDocumentUploaded;
	private String source;
	private String userId;
	private String uploadDocReferenceNumber;
	private String policyYear;
	private String rejectionRemark;
	private String pan;
	private String authorizedBy;
	private String authrizedOn;
	private String closureRemark;
	private String recordId;
	private String status;
	private String searchBy;
	private String start;
	private String limit;
	private String renewalDate;
	private String isClosureFormReviewed;

	private String districtDesc;

	private String requestId;
	
	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}


	public String getSchemeType() {
		return schemeType;
	}

	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}

	public String getMasterPolicyNumber() {
		return masterPolicyNumber;
	}

	public void setMasterPolicyNumber(String masterPolicyNumber) {
		this.masterPolicyNumber = masterPolicyNumber;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAnyDisability() {
		return anyDisability;
	}

	public void setAnyDisability(String anyDisability) {
		this.anyDisability = anyDisability;
	}

	public String getDisabilityRemarks() {
		return disabilityRemarks;
	}

	public void setDisabilityRemarks(String disabilityRemarks) {
		this.disabilityRemarks = disabilityRemarks;
	}

	public String getDateOfApplication() {
		return dateOfApplication;
	}

	public void setDateOfApplication(String dateOfApplication) {
		this.dateOfApplication = dateOfApplication;
	}

	public String getSourcingCode() {
		return sourcingCode;
	}

	public void setSourcingCode(String sourcingCode) {
		this.sourcingCode = sourcingCode;
	}

	public String getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getBranchCategory() {
		return branchCategory;
	}

	public void setBranchCategory(String branchCategory) {
		this.branchCategory = branchCategory;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getIfsCode() {
		return ifsCode;
	}

	public void setIfsCode(String ifsCode) {
		this.ifsCode = ifsCode;
	}

	public List<KycDetail> getKycDetails() {
		return kycDetails;
	}

	public void setKycDetails(List<KycDetail> kycDetails) {
		this.kycDetails = kycDetails;
	}

	public String getNomineeName() {
		return nomineeName;
	}

	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}

	public String getNomineeRelationWithSubscriber() {
		return nomineeRelationWithSubscriber;
	}

	public void setNomineeRelationWithSubscriber(String nomineeRelationWithSubscriber) {
		this.nomineeRelationWithSubscriber = nomineeRelationWithSubscriber;
	}

	public String getNomineeDob() {
		return nomineeDob;
	}

	public void setNomineeDob(String nomineeDob) {
		this.nomineeDob = nomineeDob;
	}

	public String getNomineeAge() {
		return nomineeAge;
	}

	public void setNomineeAge(String nomineeAge) {
		this.nomineeAge = nomineeAge;
	}

	public String getNomineeAddress() {
		return nomineeAddress;
	}

	public void setNomineeAddress(String nomineeAddress) {
		this.nomineeAddress = nomineeAddress;
	}

	public String getNomineeMobileNumber() {
		return nomineeMobileNumber;
	}

	public void setNomineeMobileNumber(String nomineeMobileNumber) {
		this.nomineeMobileNumber = nomineeMobileNumber;
	}

	public String getNomineeEmailId() {
		return nomineeEmailId;
	}

	public void setNomineeEmailId(String nomineeEmailId) {
		this.nomineeEmailId = nomineeEmailId;
	}

	public String getGuardianName() {
		return guardianName;
	}

	public void setGuardianName(String guardianName) {
		this.guardianName = guardianName;
	}

	public String getRelationshipWithGuardian() {
		return relationshipWithGuardian;
	}

	public void setRelationshipWithGuardian(String relationshipWithGuardian) {
		this.relationshipWithGuardian = relationshipWithGuardian;
	}

	public String getGuardianMobileNo() {
		return guardianMobileNo;
	}

	public void setGuardianMobileNo(String guardianMobileNo) {
		this.guardianMobileNo = guardianMobileNo;
	}

	public String getGuardianEmailId() {
		return guardianEmailId;
	}

	public void setGuardianEmailId(String guardianEmailId) {
		this.guardianEmailId = guardianEmailId;
	}

	public String getFormBase64() {
		return formBase64;
	}

	public void setFormBase64(String formBase64) {
		this.formBase64 = formBase64;
	}

	public String getRegistrationBranchCode() {
		return registrationBranchCode;
	}

	public void setRegistrationBranchCode(String registrationBranchCode) {
		this.registrationBranchCode = registrationBranchCode;
	}

	public String getKycDocumentSubmittedByCustomer() {
		return kycDocumentSubmittedByCustomer;
	}

	public void setKycDocumentSubmittedByCustomer(String kycDocumentSubmittedByCustomer) {
		this.kycDocumentSubmittedByCustomer = kycDocumentSubmittedByCustomer;
	}

	public String getKycIDNumberOfSubscriber() {
		return kycIDNumberOfSubscriber;
	}

	public void setKycIDNumberOfSubscriber(String kycIDNumberOfSubscriber) {
		this.kycIDNumberOfSubscriber = kycIDNumberOfSubscriber;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public String getModifyBy() {
		return modifyBy;
	}

	public String getModifyOn() {
		return modifyOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	public void setModifyOn(String modifyOn) {
		this.modifyOn = modifyOn;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getIsDocumentUploaded() {
		return isDocumentUploaded;
	}

	public void setIsDocumentUploaded(String isDocumentUploaded) {
		this.isDocumentUploaded = isDocumentUploaded;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUploadDocReferenceNumber() {
		return uploadDocReferenceNumber;
	}

	public void setUploadDocReferenceNumber(String uploadDocReferenceNumber) {
		this.uploadDocReferenceNumber = uploadDocReferenceNumber;
	}

	public String getPolicyYear() {
		return policyYear;
	}

	public void setPolicyYear(String policyYear) {
		this.policyYear = policyYear;
	}

	public String getRejectionRemark() {
		return rejectionRemark;
	}

	public void setRejectionRemark(String rejectionRemark) {
		this.rejectionRemark = rejectionRemark;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getAuthorizedBy() {
		return authorizedBy;
	}

	public String getAuthrizedOn() {
		return authrizedOn;
	}

	public void setAuthorizedBy(String authorizedBy) {
		this.authorizedBy = authorizedBy;
	}

	public void setAuthrizedOn(String authrizedOn) {
		this.authrizedOn = authrizedOn;
	}

	public String getClosureRemark() {
		return closureRemark;
	}

	public void setClosureRemark(String closureRemark) {
		this.closureRemark = closureRemark;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSearchBy() {
		return searchBy;
	}

	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	public String getRenewalDate() {
		return renewalDate;
	}

	public void setRenewalDate(String renewalDate) {
		this.renewalDate = renewalDate;
	}

	public String getIsClosureFormReviewed() {
		return isClosureFormReviewed;
	}

	public void setIsClosureFormReviewed(String isClosureFormReviewed) {
		this.isClosureFormReviewed = isClosureFormReviewed;
	}

	
	public String getIsRegistrationReviewed() {
		return isRegistrationReviewed;
	}

	public void setIsRegistrationReviewed(String isRegistrationReviewed) {
		this.isRegistrationReviewed = isRegistrationReviewed;
	}

	
	public String getDistrictDesc() {
		return districtDesc;
	}

	public void setDistrictDesc(String districtDesc) {
		this.districtDesc = districtDesc;
	}

	@Override
	public String toString() {
		return "Request [masterPolicyNumber=" + masterPolicyNumber + ", id=" + id + ", customerId=" + customerId
				+ ", customerName=" + customerName + ", fatherName=" + fatherName + ", address1=" + address1
				+ ", address2=" + address2 + ", address3=" + address3 + ", city=" + city + ", district=" + district
				+ ", state=" + state + ", pin=" + pin + ", dob=" + dob + ", gender=" + gender + ", mobileNo=" + mobileNo
				+ ", emailId=" + emailId + ", anyDisability=" + anyDisability + ", disabilityRemarks="
				+ disabilityRemarks + ", dateOfApplication=" + dateOfApplication + ", sourcingCode=" + sourcingCode
				+ ", premiumAmount=" + premiumAmount + ", branchCategory=" + branchCategory + ", accountNo=" + accountNo
				+ ", branchCode=" + branchCode + ", branchName=" + branchName + ", ifsCode=" + ifsCode + ", kycDetails="
				+ kycDetails + ", nomineeName=" + nomineeName + ", nomineeRelationWithSubscriber="
				+ nomineeRelationWithSubscriber + ", nomineeDob=" + nomineeDob + ", nomineeAge=" + nomineeAge
				+ ", nomineeAddress=" + nomineeAddress + ", nomineeMobileNumber=" + nomineeMobileNumber
				+ ", nomineeEmailId=" + nomineeEmailId + ", guardianName=" + guardianName
				+ ", relationshipWithGuardian=" + relationshipWithGuardian + ", guardianMobileNo=" + guardianMobileNo
				+ ", guardianEmailId=" + guardianEmailId + ", formBase64=" + formBase64 + ", schemeType=" + schemeType
				+ ", registrationBranchCode=" + registrationBranchCode + ", kycDocumentSubmittedByCustomer="
				+ kycDocumentSubmittedByCustomer 
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", modifyBy=" + modifyBy + ", modifyOn="
				+ modifyOn + ", channel=" + channel + ", isDocumentUploaded=" + isDocumentUploaded + ", source="
				+ source + ", userId=" + userId + ", uploadDocReferenceNumber=" + uploadDocReferenceNumber
				+ ", policyYear=" + policyYear + ", rejectionRemark=" + rejectionRemark 
				+ ", authorizedBy=" + authorizedBy + ", authrizedOn=" + authrizedOn + ", closureRemark=" + closureRemark
				+ ", recordId=" + recordId + ", status=" + status + ", searchBy=" + searchBy + ", start=" + start
				+ ", limit=" + limit + ", renewalDate=" + renewalDate + "]";
	}

}

