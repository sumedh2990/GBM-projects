package com.pmscheme.controller;

import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pmscheme.core.plugin.PluginException;
import com.pmscheme.core.util.Constants;
import com.pmscheme.exception.ServiceException;
import com.pmscheme.model.Request;
import com.pmscheme.service.PmSchemeService;
import com.pmscheme.service.lock.LockService;
import com.pmscheme.web.model.ResponsePayloadAPI;
import com.winsoft.util.Constant;
import com.winsoft.util.MessageLogger;
import com.winsoft.util.MessageUtility;
import com.winsoft.util.StringUtil;
import com.winsoft.util.Utility;

@Controller
@RequestMapping("/api")
public class RequestAPIController {

	private static final Logger logger = LoggerFactory.getLogger(RequestAPIController.class);

	//@Autowired
	private Map<String, Object> validationProperties;
	
	private Map<String, Object> messagesProperties;


	@Autowired
	private PmSchemeService pmSchemeService;

	@Autowired
	LockService lockService;
	
	@Autowired
	@Qualifier("registraionAPIFieldMapping")
	private Properties apiFieldMapping;

	@SuppressWarnings("unchecked")
	@PostConstruct
	void init() {
		try {

			validationProperties = (Map<String, Object>) new ObjectMapper().readValue(new InputStreamReader(
					new ClassPathResource("api-validation-config.json", this.getClass().getClassLoader())
							.getInputStream()),
					Map.class);

			messagesProperties = (Map<String, Object>) new ObjectMapper().readValue(
					new InputStreamReader(
							new ClassPathResource("messages.json", this.getClass().getClassLoader()).getInputStream()),
					Map.class);

			MessageUtility.loadMessages((List) messagesProperties.get("messages"));
			MessageUtility.loadValidation(validationProperties);
		} catch (Exception e) {
			MessageLogger.debug(logger, "Error while loading details" + e);
		}
	}

	@ExceptionHandler
	public @ResponseBody ResponsePayloadAPI handleException(MethodArgumentNotValidException exception) {

		StringBuffer errBuf = new StringBuffer();
		List<String> errBufList = new ArrayList<>();
		List<ObjectError> objErrors = exception.getBindingResult().getAllErrors();
		for (ObjectError error : objErrors) {
			errBufList.add(error.getDefaultMessage());
		}

		return new ResponsePayloadAPI(1, "Validation failed! ", errBufList);
	}

	private boolean isValidBody2(String apiName, Map<String, String> body) throws ServiceException {
		try {
			Map<String, Object> body2 = new LinkedHashMap<>();
			for (Map.Entry<String, String> map : body.entrySet()) {
				body2.put(map.getKey(), map.getValue());
			}
			return isValidBody(apiName, body2);
		} catch (Exception ex) {
			if (ex instanceof ServiceException) {
				throw ex;
			}
		}
		return false;
	}

	private boolean isValidBody(String apiName, Map<String, Object> body) throws ServiceException {
		try {

			Map registrationApi = (Map) validationProperties.get(apiName);
			System.out.println("registrationApi:" + registrationApi);
			List<String> reqField = (List<String>) registrationApi.get("requiredField");
			if (reqField != null) {
				Set<String> set = new HashSet<>();
				Set<String> setReqField = new HashSet<>(reqField);
				for (Map.Entry<String, Object> map1 : body.entrySet()) {
					set.add(map1.getKey());
				}
				// System.out.println("registrationApi" + setReqField);
				setReqField.removeAll(set);
				// System.out.println("registrationApi" + setReqField);
				if (setReqField != null && setReqField.size() > 0) {
					throw new ServiceException(true, "Field are missing in request : " + setReqField);
				}
			}

			for (Map.Entry<String, Object> map : body.entrySet()) {
				{
					Map<String, Object> obj = (Map<String, Object>) registrationApi.get(map.getKey());
					if (obj != null) {
						if (map.getValue() != null) {
							if ((List) obj.get("errorOnMatch") != null) {
								StringUtil.validateField(map.getKey(), (String) map.getValue(), (List) obj.get("regx"),
										(List) obj.get("errorOnMatch"), (List) obj.get("msg"), (List) obj.get("code"));
							} else {
								StringUtil.validateField(map.getKey(), (String) map.getValue(), (List) obj.get("regx"),
										(List) obj.get("msg"), (List) obj.get("code"));
							}
						}
					}
				}
			}
			return true;
		} catch (ServiceException e) {
			throw e;
		}
	}

	
	
	@PostMapping("/registration")
	public @ResponseBody ResponsePayloadAPI createRegistrationRequest(@RequestBody Map<String,Object> requestBody,HttpServletRequest httpRequest) {
		MessageLogger.debug(logger, String.format("createRegistrationRequest(%s)", requestBody));
		Map<String,String> header = (Map<String, String>) requestBody.get(Constant.HEADER);
		Map<String,String> body = (Map<String, String>) requestBody.get(Constant.BODY);
		ResponsePayloadAPI resp=null;
		final ObjectMapper mapper = new ObjectMapper();
		try {
			//get&setMappingField
			setAndGetNsdlParam(body);
			isValidHeader("headers", header);
			isValidBody2("registraion-api-digital", body);
			MessageLogger.debug(logger, String.format("setAndGetNsdlParam(%s)", body));
			
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			
			pmSchemeService.saveAPIReqResp(body,
					header, mapper.writeValueAsString(requestBody), null, null, null,
					"Registration API", httpRequest.getRequestURI());
			
			
			final Request request = mapper.convertValue(body, Request.class);
			request.setChannel(Constants.DIGITAL);
			request.setCreatedBy(request.getCustomerId());
			request.setSource(header.get("sourceApp"));
			request.setUserId(request.getCustomerId());
			Map<String, Object> result = pmSchemeService.createDigitalRequest(request,body);
			resp = new ResponsePayloadAPI(HttpStatus.ACCEPTED.OK.value(),true,header,(String)result.get(Constants.MSG), new ArrayList<>());
		} catch (Exception ex) {
			MessageLogger.debug(logger, "Error while creating Registration request: " + ex);
			if (ex instanceof ServiceException) {
				ServiceException ex1 = (ServiceException) ex;
				resp = new ResponsePayloadAPI(ex1.getErrorCode(),false,header,ex.getLocalizedMessage(), new ArrayList<>());
			}else {
				resp = new ResponsePayloadAPI(-1,false,header,"Error while processing registration request", new ArrayList<>());
			}
		}finally {
			try {
				MessageLogger.debug(logger, String.format("accountClosureAPI : "+resp.getStatus()));
				pmSchemeService.saveAPIReqResp((Map<String, String>) requestBody.get("body"),
						(Map<String, String>) requestBody.get(Constant.HEADER), mapper.writeValueAsString(requestBody),
						mapper.writeValueAsString(resp), (resp != null) ? resp.getStatus() + "" : null,
						(resp != null) ? resp.getMsg() : null, "Registration API", httpRequest.getRequestURI());
			} catch (Exception ex) {
				MessageLogger.error(logger, String.format(MessageUtility.getMessage("notRegistered").getMessage(), body.get("schemeType")), ex);
			}
		}
		return resp;
	}
	
	@PostMapping(value = "/customer-summary-details")
	public @ResponseBody ResponsePayloadAPI customerSummaryDetails(@RequestBody Map<String, Object> requestBody, HttpServletRequest request) throws Exception {
		MessageLogger.debug(logger, String.format("customerSummaryDetails({response = %s})", requestBody));

		Map<String,String> header = (Map<String, String>) requestBody.get(Constant.HEADER);
		Map<String,String> body = (Map<String, String>) requestBody.get(Constant.BODY);

		ResponsePayloadAPI response = null;
		List<Map<String, Object>> result = null;
		final ObjectMapper mapper = new ObjectMapper();

		try {
			pmSchemeService.saveAPIReqResp(body,
					header, mapper.writeValueAsString(requestBody), null, null, null,
					"Customer Summary Details API", request.getRequestURI());

			isValidHeader("headers", header);
			isValidBody2("customerdetailssummary-api", body);

			result = this.pmSchemeService.customerSummaryDetails(body);

			if (!result.isEmpty()) {
				response = new ResponsePayloadAPI(201, header, MessageUtility.getMessage("getCustomer").getMessage(), result);
			}
			else {
				response = new ResponsePayloadAPI(201, header, String.format(MessageUtility.getMessage("notRegistered").getMessage(), body.get("schemeType")), null);
			}
		} catch (ServiceException e) {
			MessageLogger.error(logger, String.format(MessageUtility.getMessage("notRegistered").getMessage(), body.get("schemeType")), e);
			response = new ResponsePayloadAPI(e.getErrorCode(), header, e.getLocalizedMessage(), null);
		}
		finally {
			try {
				pmSchemeService.saveAPIReqResp((Map<String, String>) requestBody.get("body"),
						(Map<String, String>) requestBody.get(Constant.HEADER), mapper.writeValueAsString(requestBody),
						mapper.writeValueAsString(response), (response != null) ? response.getStatus() + "" : null,
						(response != null) ? response.getMsg() : null, "Customer Summary Details API", request.getRequestURI());
			} catch (Exception ex) {
				MessageLogger.error(logger, String.format(MessageUtility.getMessage("notRegistered").getMessage(), body.get("schemeType")), ex);
			}
		}

		return response;
	}

	private boolean isValidHeader(String apiName, Map<String, String> header) throws ServiceException {
		try {
			Map headers = (Map) validationProperties.get(apiName);
			List<String> reqField = (List<String>) headers.get("requiredField");
			if (reqField != null) {
				Set<String> set = new HashSet<>();
				Set<String> setReqField = new HashSet<>(reqField);

				for (Map.Entry<String, String> map1 : header.entrySet()) {
					set.add(map1.getKey());
				}

				setReqField.removeAll(set);
				System.out.println("setReqField: "+setReqField.toString());
				if (setReqField != null && setReqField.size() > 0) {
					throw new ServiceException(false,9001, "Field is missing in request : " + setReqField);
				}
			}

			for (Map.Entry<String, String> map : header.entrySet()) {
				{
					Map<String, Object> obj = (Map<String, Object>) headers.get(map.getKey());
					if (obj != null) {
						StringUtil.validateField(map.getKey(), (String) map.getValue(), (List) obj.get("regx"),
								(List) obj.get("msg"), (List) obj.get("code"));
					}
				}
				if (!StringUtils.isEmpty(header.get("timesStamp"))) { // 05:20:32
					try {
						LocalDateTime dobDateTime = LocalDateTime.parse(header.get("timesStamp"), DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm:ss a"));
						LocalDateTime startOfDay = LocalDate.now().atStartOfDay();
						LocalDateTime endOfDay = startOfDay.plusDays(1);

						// Check if the timestamp is not within today's date range
						if (dobDateTime.isBefore(startOfDay)) {
							throw new ServiceException(true, MessageUtility.getMessage("timesStampPastDate").getCode(),
									MessageUtility.getMessage("timesStampPastDate").getMessage());
						} else if(dobDateTime.isAfter(endOfDay)) {
							throw new ServiceException(true, MessageUtility.getMessage("timesStampFutureDate").getCode(),
									MessageUtility.getMessage("timesStampFutureDate").getMessage());
						}
				    } catch (DateTimeParseException ex) {
				        throw new ServiceException(true, MessageUtility.getMessage("timesStampFutureDate").getCode(),
				        		 "Timestamp is Invalid");
				    } 
				}
			
//			if (!StringUtils.isEmpty(header.get("timesStamp"))) {
//			    try {
//			        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
//			        LocalDateTime dobDateTime = LocalDateTime.parse(header.get("timesStamp"), formatter);
//
//			        if (dobDateTime.isAfter(LocalDateTime.now())) {
//			            throw new ServiceException(true, MessageUtility.getMessage("timesStampFutureDate").getCode(),
//			                    MessageUtility.getMessage("timesStampFutureDate").getMessage());
//			        }
//			    } catch (DateTimeParseException ex) {
//			        throw new ServiceException(true, MessageUtility.getMessage("timesStampFutureDate").getCode(),
//			                MessageUtility.getMessage("timesStampFutureDate").getMessage());
//			    }
//			}


//			if(!StringUtils.isEmpty( header.get("sourceServerIp"))){
//				Map<String,List> gaurdianNameList = (Map<String, List>) MessageUtility.getValidationProps("optionalField").get("sourceServerIp");	
//				StringUtil.validateField("sourceServerIp", header.get("sourceServerIp"),
//						gaurdianNameList.get("regx"),gaurdianNameList.get("msg"), gaurdianNameList.get("code"));
//			}

			if(!StringUtils.isEmpty( header.get("serviceRequestId"))){
				Map<String,List> gaurdianNameList = (Map<String, List>) MessageUtility.getValidationProps("optionalField").get("serviceRequestId");	
				StringUtil.validateField("serviceRequestId", header.get("serviceRequestId"),
						gaurdianNameList.get("regx"),gaurdianNameList.get("msg"), gaurdianNameList.get("code"));
			}
			}
			isValidSourceApp(header);
			return true;
		} catch (ServiceException e) {
			throw e;
		}
	}

	@RequestMapping(value = "/closure", method = RequestMethod.POST)
	public @ResponseBody ResponsePayloadAPI accountClosure(@RequestBody Map<String,Object> requestBody, HttpServletRequest request) throws Exception {
		MessageLogger.debug(logger, String.format("accountClosureAPI"));
		String customerId;
		ResponsePayloadAPI response= null;


		Map<String,String> header = (Map<String, String>) requestBody.get(Constant.HEADER);
		Map<String,String> body = (Map<String, String>) requestBody.get(Constant.BODY);

		final ObjectMapper mapper = new ObjectMapper();
			customerId = (String) body.get("customerId");
			try {
				pmSchemeService.saveAPIReqResp(body,
						header, mapper.writeValueAsString(requestBody), null, null, null,
						"Account Closure API", request.getRequestURI());

				isValidHeader("headers", header);
				isValidBody2(Constant.CLOSURE_API, body);

				Request reqBody = mapper.convertValue(body, Request.class);
				Map<String, Object> result = pmSchemeService.closureAPIRequest(reqBody);
				MessageLogger.debug(logger,"AccountClosure API Result: "+ result.toString());

				if (!result.isEmpty()) {

					response = new ResponsePayloadAPI((Constant.SP_SUCCESS_CODE.equals(result.get("Status").toString())) ? 200 : Constant.IS_ALREADY_CLOSED_CODE, header,
							(String) result.get(Constant.MSG), (String) result.get(Constant.RESULT));

				}

			} catch (ServiceException e) {
				MessageLogger.error(logger, String.format(MessageUtility.getMessage("notRegistered").getMessage(), body.get("scheme")), e);
				response =  new ResponsePayloadAPI(e.getErrorCode(),header, e.getLocalizedMessage(),null);
			}
			finally {
				try {
					MessageLogger.debug(logger, String.format("accountClosureAPI : "+response.getMsg()));
					pmSchemeService.saveAPIReqResp((Map<String, String>) requestBody.get("body"),
							(Map<String, String>) requestBody.get(Constant.HEADER), mapper.writeValueAsString(requestBody),
							mapper.writeValueAsString(response), (response != null) ? response.getStatus() + "" : null,
							(response != null) ? response.getMsg() : null, "Account Closure API", request.getRequestURI());
				} catch (Exception ex) {
					MessageLogger.error(logger, String.format(MessageUtility.getMessage("notRegistered").getMessage(), body.get("scheme")), ex);
				}
			}
			return response;
	}

	@RequestMapping(value = "/cust-eligibility", method = RequestMethod.POST)
	public @ResponseBody ResponsePayloadAPI checkCustomerEligibility(@RequestBody Map<String, Object> requestBody,
			HttpServletRequest request) throws Exception {
		MessageLogger.debug(logger, String.format("cust-eligibility(requestBody = %s)", requestBody));
		ResponsePayloadAPI response = null;
		final ObjectMapper mapper = new ObjectMapper();
		Map<String, String> header = (Map<String, String>) requestBody.get(Constant.HEADER);
		Map<String, Object> body = (Map<String, Object>) requestBody.get(Constant.BODY);

		boolean isValidRequestBody = false;
		Map<String, String> reqBody = (Map<String, String>) requestBody.get(Constant.BODY);
		String customerId = (String) body.get("customerId");
		Map<String, Object> checkResult = null;
		Map<String, Object>  mapForRenewalStarted = null;

		try {
			mapForRenewalStarted = pmSchemeService.getIsRenewalPeriodStarted();
			pmSchemeService.saveAPIReqResp(reqBody, header, mapper.writeValueAsString(requestBody), null, null, null,
					Constant.ONLINE_ELIGIBILTY_API, request.getRequestURI());

			isValidHeader("headers", header);
			isValidRequestBody = isValidBody(Constant.ELIGIBILITY_API, body);

			checkResult = pmSchemeService.getCustomerEligibilityDetail(reqBody);
			if (checkResult != null && !checkResult.isEmpty()) {
				response = new ResponsePayloadAPI(200, header, (String) checkResult.get(Constant.MSG),
						checkResult.get(Constant.RESULT), checkResult.get(Constant.IS_EXISTING_CUSTOMER),mapForRenewalStarted.get("isRestrictionEnabled"));
			} else {
	            throw new ServiceException(false,"Could not fetch the details");
	        }
			return response;

		} catch (ServiceException ex) {
			MessageLogger.error(logger, "Error While Processing eligibility API", ex);
//			int statusCode = 0;
//			if(ex.getErrorCode() == -1) {
//				statusCode = 202;
//			}
			String existingCustomer;
//
			String localizedMessage = ex.getLocalizedMessage();
			String schemeType = reqBody.get("schemeType");

			if (localizedMessage != null && schemeType != null) {
			    String expectedMessage = "You are already registered with " + schemeType + " Scheme.";
			    if (localizedMessage.equals(expectedMessage)) {
			        existingCustomer = Constant.Y_VAL;
			    } else {
			        existingCustomer = Constant.N_VAL;
			    }
			} else {
			    existingCustomer = Constant.N_VAL;
			}
			String renewalStartedMessage = "";
			int renewalStartedCode;
			if(Constants.N_VAL.equalsIgnoreCase((String) mapForRenewalStarted.get("isRestrictionEnabled")) && mapForRenewalStarted.get("msg") != null) {
				renewalStartedMessage = (String) mapForRenewalStarted.get("msg");
				renewalStartedCode = MessageUtility.getMessage("accountAlreadyClosedInPolicyYearCustSummary").getCode();
			} else {
				renewalStartedMessage = ex.getLocalizedMessage();
				renewalStartedCode =  ex.getErrorCode();
			}
//			if (localizedMessage != null && schemeType != null) {
//			    String expectedMessage = "Unable to fetch premium amount for " + schemeType;
//			    if(localizedMessage.equals(expectedMessage)) {
//			    	statusCode = 9013;
//			    }
//			}
			
//			if (localizedMessage != null && schemeType != null) {
//			    String expectedMessage = "Your policy is valid for the current policy year and will not be renewed next year";
//			    if(localizedMessage.equals(expectedMessage)) {
//			    	statusCode = 203;
//			    }
//			}
			response = new ResponsePayloadAPI(renewalStartedCode, header, renewalStartedMessage, null, existingCustomer,mapForRenewalStarted.get("isRestrictionEnabled"));
			return response;
		} finally {
			try {
				pmSchemeService.saveAPIReqResp((Map<String, String>) requestBody.get(Constant.BODY),
						(Map<String, String>) requestBody.get(Constant.HEADER), mapper.writeValueAsString(requestBody),
						mapper.writeValueAsString(response),
						(response != null) ? String.valueOf(response.getStatus()) : null,
						(response != null) ? response.getMsg() : null, Constant.ONLINE_ELIGIBILTY_API,
						request.getRequestURI());
			} catch (Exception ex) {
				MessageLogger.error(logger, "Error while inserting request response", ex);
			}
		}
	}

	private boolean isValidSourceApp(Map<String, String> header) throws ServiceException {
		MessageLogger.debug(logger, String.format("isValidSourceApp(%s)", header));
		try {
			if (!StringUtils.isEmpty(header.get("sourceApp"))) {
				try {
					boolean result = pmSchemeService.isValidSourceApp(header.get("sourceApp").toString());
					Map<String, List> sourceAppList = (Map<String, List>) MessageUtility.getValidationProps("headers").get("sourceApp");
					if (result == true) {
						StringUtil.validateField("sourceApp", header.get("sourceApp"), sourceAppList.get("regx"),
								sourceAppList.get("msg"), sourceAppList.get("code"));
					} else {
						throw new ServiceException(false, MessageUtility.getMessage("sourceAppNotExist").getCode(),
								MessageUtility.getMessage("sourceAppNotExist").getMessage());
					}
				} catch (ServiceException ex) {
					throw ex;
				}
			}
			return true;
		} catch (ServiceException ex) {
			throw ex;
		}

	}
	
	private Map<String,String> setAndGetNsdlParam(Map<String, String> requestBody){
			MessageLogger.debug(logger, "apiFieldMapping: "+ apiFieldMapping);
			requestBody.put("premiumAmount", requestBody.get(apiFieldMapping.get("premiumAmount")));
			requestBody.put("kycDocumentSubmittedByCustomer", requestBody.get(apiFieldMapping.get("kycDocumentSubmittedByCustomer")));
			requestBody.put("kycIDNumberOfSubscriber", requestBody.get(apiFieldMapping.get("kycIDNumberOfSubscriber")));
			requestBody.put("nomineeRelationWithSubscriber", requestBody.get(apiFieldMapping.get("nomineeRelationWithSubscriber")));
			requestBody.put("nomineeMobileNumber", requestBody.get(apiFieldMapping.get("nomineeMobileNumber")));
			requestBody.put("sourcingCode", requestBody.get(apiFieldMapping.get("sourcingCode")));
			return requestBody;
		}

	}

