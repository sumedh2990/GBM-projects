




@Override
	public Map<String, Object> createDigitalRequest(Request request,Map<String, String> body) throws ServiceException {
		MessageLogger.debug(logger, String.format("createDigitalRequest(%s)", request.getCustomerId()));
		try {
			
			Map<String, String> param2 = new HashMap<>();
			param2.put(Constants.CUSTOMER_ID, request.getCustomerId());
			param2.put(Constants.ACCOUNT_NO, request.getAccountNo());
			param2.put(Constants.IS_VALIDATE_CUST_TYPE, Constants.N_VAL);
			
			String balance = getBalance(param2);

			float availableBalance = Float.valueOf(balance);
			float premiumAmount = Float.valueOf(request.getPremiumAmount());
			logger.debug("Available Balance : " + balance + "\t" + "PremiumAmount: " + premiumAmount);
			if (availableBalance < premiumAmount) {
				throw new ValidationException(true, MessageUtility.getMessage("insufficientBalanceError").getCode(),
						MessageUtility.getMessage("insufficientBalanceErrorMaker").getMessage());
			}
					
			
			if(!StringUtils.isEmpty(request.getAnyDisability()) && request.getAnyDisability().equalsIgnoreCase(Constants.Y_VAL) ) {
				try {
					Map<String, List> anyDisability = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
							.get("disabilityRemarks");
					StringUtil.validateField("disabilityRemarks", request.getDisabilityRemarks(), anyDisability.get("regx"),
							anyDisability.get("errorOnMatch"), anyDisability.get("msg"), anyDisability.get("code"));
				} catch (ServiceException e) {
					throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
				}
			}
			
			if(!StringUtils.isEmpty(request.getAnyDisability()) && request.getAnyDisability().equalsIgnoreCase(Constants.N_VAL) ) {
				if(!StringUtils.isEmpty(request.getDisabilityRemarks())) {
					throw new ValidationException(true, MessageUtility.getMessage("disabiltyRemarkNotBlank").getCode(), 
							MessageUtility.getMessage("disabiltyRemarkNotBlank").getMessage());
				}
			}
			
//			MessageLogger.debug(logger, "NomineeNumber: "+ request.getNomineeMobileNumber());
//			if(!StringUtils.isEmpty(request.getNomineeMobileNumber())) {
//				try {
//					Map<String, List> nomineeMob = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
//							.get("nomineeMobileNumber");
//					StringUtil.validateField("disabilityRemarks", request.getNomineeMobileNumber(),  nomineeMob.get("regx"),
//							 nomineeMob.get("errorOnMatch"),  nomineeMob.get("msg"),  nomineeMob.get("code"));
//				} catch (ServiceException e) {
//					throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
//				}
//			}
			
			
			
			isRegistrationsRestrictPeriod();
			validateRequestBodyAPI(request,body);
			request.setPolicyYear(getPolicyYear());
			
			Map<String, String> custParam = new HashMap<>();
			custParam.put("customerId", request.getCustomerId());
			custParam.put("schemeType", request.getSchemeType());
			custParam.put("isUpdateRequest", (request.getId() == null?"N":"Y"));
			custParam.put("premiumAmt", request.getPremiumAmount());
			custParam.put(Constants.IS_VALIDATE_CUST_TYPE, Constants.N_VAL);
			custParam.put(Constants.ACCOUNT_NO, request.getAccountNo());
			Map<String, Object> customerInfo = getCustomerInfo(custParam);
			for (KYCDocumentEnum document : KYCDocumentEnum.values()) {
				if (request.getKycDocumentSubmittedByCustomer().equalsIgnoreCase(document.getDocReferenceNo())) {
					request.setKycDocumentSubmittedByCustomer(document.getDocument());
				}
			}
			Map<String, Object> result = pmSchemeDao.createDigital(request,customerInfo);
			String tableInsertStatus = ((result!=null)?(String)result.get(Constants.SUCCESS):Constants.N_VAL);
			if (tableInsertStatus != null && tableInsertStatus.equalsIgnoreCase(Constants.Y_VAL)) {
				
				request.setId((String) result.get(Constants.ID));
				MessageLogger.debug(logger, String.format("Request is submitted: %s", result));
				
				if ((!pmSchemeDao.isEodStarted() && !pmSchemeDao.isEodFinished()) && !pmSchemeDao.isHoliday()) {
					Map<String, String> ftConfig = new HashMap<>();
					ftConfig.put(Constants.IS_USE_CALLED_BALANCE_API, Constants.N_VAL);
					ftConfig.put(Constants.IS_VERIFY_REQUEST, Constants.Y_VAL);
					this.transactionService.executeTransaction(request, ftConfig);
					Request alertRequest = getRequestById(request.getId());

//					CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(new Runnable() {
//						@Override
//						public void run() {
//							createPmRequestAlert(alertRequest, request.getUserId());
//						}
//					});
				}
				else {
					if(pmSchemeDao.isEodFinished() && pmSchemeDao.isRestrictionPeriodStarted()) {
						throw new DaoException(true,
								MessageUtility.getMessage("registrationRestrictionPeriod").getCode() + "",
								MessageUtility.getMessage("registrationRestrictionPeriod").getMessage());
					}
					MessageLogger.debug(logger, String.format("amountHoldResult(%s)", request.getCustomerId()));
					custParam.put(Constants.CLIENT_REFERENCE_NO, getReferenceNumber("PM"));
					Map<String, Object> amountHoldResult = bankService.startAmountHold(custParam, serviceProperties);
					if (amountHoldResult != null) {
						String status = (String) amountHoldResult.get(Constants.SUCCESS);
						MessageLogger.debug(logger, String.format("status(%s)", status));
						if (status != null && status.equalsIgnoreCase(Constants.Y_VAL)) {
							amountHoldResult.put(Constants.REQUEST_ID, request.getId());
							commonService.addDataTOReqRespMapping(amountHoldResult);
						} else {
							request.setRejectionRemark(
									MessageUtility.getMessage("AmountholdrequestFailed").getMessage());
							Map<String, String> resultMap = pmSchemeDao.rejectPMReqquest(request);
							throw new DaoException(true,
									MessageUtility.getMessage("AmountholdrequestFailed").getCode() + "",
									MessageUtility.getMessage("AmountholdrequestFailed").getMessage());
						}
					} else {
						Map<String, String> resultMap = pmSchemeDao.rejectPMReqquest(request);
						throw new DaoException(true,
								MessageUtility.getMessage("AmountholdrequestFailed").getCode() + "",
								MessageUtility.getMessage("AmountholdrequestFailed").getMessage());
					}
					// processStageRegistrationRecords();
				}
				// What will be message for holiday registration
				return result;
			}
		return result;

		}catch (TransactionException ex) {
			MessageLogger.error(logger, "Error while processing transaction request : " + ex);
			try {
				if (!StringUtil.isEmpty(ex.getLocalizedMessage()))
					request.setRejectionRemark(ex.getLocalizedMessage());
				else {
					request.setRejectionRemark(ex.getMessage());
				}
				Map<String, String> resultMap = pmSchemeDao.rejectPMReqquest(request);
				MessageLogger.debug(logger, "Record rejected Successfully");
			} catch (DaoException e) {
				MessageLogger.debug(logger, "Error while rejecting record " + e);
			}
			if (ex.getErrorCode() != null && ex.isFormatted())
				throw new ServiceException(true, ex.getErrorCode(), ex.getLocalizedMessage());
			else {
				throw new ServiceException(true, -1, ex.getLocalizedMessage());
			}
		} 
		catch (ValidationException ex) {
			MessageLogger.error(logger, "Error while validating registration request : " + ex);
			if (ex.getErrorCode() != null && ex.isFormatted())
				throw new ServiceException(true, (ex.getErrorCode()), ex.getLocalizedMessage());
			else {
				throw new ServiceException(true, -1, ex.getLocalizedMessage());
			}
		} catch (DaoException ex) {
			MessageLogger.error(logger, "Error while creating registration request : " + ex);
			if (ex.getCode() != null && ex.isFormatted())
				throw new ServiceException(true, Integer.parseInt(ex.getCode()), ex.getLocalizedMessage());
			else {
				throw new ServiceException(true, -1, ex.getLocalizedMessage());
			}
		}
	}
	
	
	
	
		@Override
	public String getBalance(Map<String,String> param) throws ServiceException {
		MessageLogger.debug(logger, String.format("getBalance(%s)", param));
		Map<String, String> accountMap;
		try {
			param.put(Constants.IS_VALIDATE_CUST_TYPE, Constants.N_VAL);
			accountMap = pmSchemeDao.searchAndGetAccount(param);
			return accountMap.get(Constants.AVAILABLE_BALANCE);
		} catch (DaoException e) {
			String errorCode = e.getCode();
			if(errorCode==null) {
				errorCode="-1";
			}
			throw new ServiceException(true,Integer.parseInt(errorCode),e.getLocalizedMessage());
		}
		
	}
	
	public boolean isRegistrationsRestrictPeriod() throws ValidationException {
		MessageLogger.debug(logger, "isAllowedRegistration()");
		try {
			boolean result = pmSchemeDao.isRegistrationsRestrictPeriod();
			return result;
		} catch (Exception e) {
			if(e instanceof ValidationException) {
				MessageLogger.error(logger, "Registration restriction period has been started so registration could not process");
				throw e;
			}
			else {
				MessageLogger.error(logger, "Error while isAllowedRegistration validating: "+ e);
				throw new ValidationException("Error while isAllowedRegistration validating");
			}
		}
	}
	
	
	@Override
	public boolean isRegistrationsRestrictPeriod() throws ValidationException {
		MessageLogger.debug(logger, "isRegistrationsRestrictPeriod()");
		try {
			Map<String, Object> namedParameter = new HashMap<>();
			namedParameter.put("registrationNotAllowed", "registrationRestrictionPeriod");

			String getConfigDateQuery = this.sqlproperties.getProperty("getConfigDate");
			List<Map<String, Object>> result = this.namedParameterJdbcTemplate.queryForList(getConfigDateQuery, namedParameter);
			
			if (!result.isEmpty()) {
				Map<String, Object> row = result.get(0);
				
		        LocalDate fromDate = LocalDate.parse(row.get("CONFIG_FROM_DATE").toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		        LocalDate toDate = LocalDate.parse(row.get("CONFIG_TO_DATE").toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		        LocalDate currentDate = LocalDate.now();

		        if (currentDate.isAfter(fromDate.minusDays(1)) && currentDate.isBefore(toDate.plusDays(1))) {
		            throw new ValidationException(true, MessageUtility.getMessage("registrationRestrictionPeriod").getCode(),
		                    String.format(MessageUtility.getMessage("registrationRestrictionPeriod").getMessage(),
		                            fromDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
		                            toDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
		        }
			}
		} catch (Exception e) {
			
			if(e instanceof ValidationException) {
				MessageLogger.error(logger, "Registration restriction period has been started so registration could not process");
				throw e;
			}
			else {
				MessageLogger.error(logger, "Error while isRegistrationsRestrictPeriod validating: "+ e);
				throw new ValidationException("Error while isRegistrationsRestrictPeriod validating");
			}
		}
		return true;
	}
	
	private void validateRequestBodyAPI(Request request, Map<String, String> body) throws ValidationException, ServiceException {

		// KYC Document
		{
			// if(request.getKycDocumentSubmittedByCustomer().equalsIgnoreCase(null))
			boolean isValidDocument = false;
			String documentName = "";
			for (KYCDocumentEnum document : KYCDocumentEnum.values()) {
				if (request.getKycDocumentSubmittedByCustomer().equalsIgnoreCase(document.getDocReferenceNo())) {
					isValidDocument = true;
					documentName = document.getDocReferenceNo();
				}
			}
			if (!isValidDocument) {
				throw new ValidationException(true, MessageUtility.getMessage("isValidKYCDocumentError").getCode(),
						MessageUtility.getMessage("isValidKYCDocumentError").getMessage());
			}

			if (documentName.equalsIgnoreCase(KYCDocumentEnum.AADHAAR.getDocReferenceNo())) {
				//MessageLogger.debug(logger, String.format("Document Name: %s, Document Id: %s", documentName,
				//		request.getKycIDNumberOfSubscriber()));
				if (!ValidationUtility.isValidAadharNumber(request.getKycIDNumberOfSubscriber())) {
					throw new ValidationException(true,
							MessageUtility.getMessage("isValidKYCDocumentIDError").getCode(),
							MessageUtility.getMessage("isValidKYCDocumentIDError").getMessage());
				}
			}

			if (documentName.equalsIgnoreCase(KYCDocumentEnum.DRIVING_LICENSE.getDocReferenceNo())) {
				//MessageLogger.debug(logger, String.format("Document Name: %s, Document Id: %s", documentName,
				//		request.getKycIDNumberOfSubscriber()));
				if (!ValidationUtility.isValidDrivingLicence(request.getKycIDNumberOfSubscriber())) {
					throw new ValidationException(true,
							MessageUtility.getMessage("isValidKYCDocumentIDError").getCode(),
							MessageUtility.getMessage("isValidKYCDocumentIDError").getMessage());
				}
			}

			if (documentName.equalsIgnoreCase(KYCDocumentEnum.ELECTORAL_PHOTO_IDENTITY_CARD_EPIC.getDocReferenceNo())) {
				//MessageLogger.debug(logger, String.format("Document Name: %s, Document Id: %s", documentName,
				//		request.getKycIDNumberOfSubscriber()));
				if (!ValidationUtility.isValidEpicNumber(request.getKycIDNumberOfSubscriber())) {
					throw new ValidationException(true,
							MessageUtility.getMessage("isValidKYCDocumentIDError").getCode(),
							MessageUtility.getMessage("isValidKYCDocumentIDError").getMessage());
				}
			}

			if (documentName.equalsIgnoreCase(KYCDocumentEnum.PAN_CARD.getDocReferenceNo())) {
				//MessageLogger.debug(logger, String.format("Document Name: %s, Document Id: %s", documentName,
				//		request.getKycIDNumberOfSubscriber()));
				if (!ValidationUtility.isValidPan(request.getKycIDNumberOfSubscriber())) {
					throw new ValidationException(true,
							MessageUtility.getMessage("isValidKYCDocumentIDError").getCode(),
							MessageUtility.getMessage("isValidKYCDocumentIDError").getMessage());
				}
			}

			if (documentName.equalsIgnoreCase(KYCDocumentEnum.PASSPORT.getDocReferenceNo())) {
				//MessageLogger.debug(logger, String.format("Document Name: %s, Document Id: %s", documentName,
			//			request.getKycIDNumberOfSubscriber()));
				if (!ValidationUtility.isValidPassportNo(request.getKycIDNumberOfSubscriber())) {
					throw new ValidationException(true,
							MessageUtility.getMessage("isValidKYCDocumentIDError").getCode(),
							MessageUtility.getMessage("isValidKYCDocumentIDError").getMessage());
				}
			}
			
			if (documentName.equalsIgnoreCase(KYCDocumentEnum.MGNREGA_CARD.getDocReferenceNo())) {
				//MessageLogger.debug(logger, String.format("Document Name: %s, Document Id: %s", documentName,
			//			request.getKycIDNumberOfSubscriber()));
				if (!ValidationUtility.isValidManRega(request.getKycIDNumberOfSubscriber())) {
					throw new ValidationException(true,
							MessageUtility.getMessage("isValidKYCDocumentIDError").getCode(),
							MessageUtility.getMessage("isValidKYCDocumentIDError").getMessage());
				}
			}
		}

		// Conditional Field Validations
		java.time.LocalDate dobDate = Utility.getDateObject(request.getNomineeDob(), "dd/MM/yyyy");
		if (dobDate.isAfter(LocalDate.now())) {
			throw new ValidationException(true, MessageUtility.getMessage("FutureDate").getCode(),
					MessageUtility.getMessage("FutureDate").getMessage());
		}
		
		java.time.LocalDate dobDate1 = Utility.getDateObject(request.getDob(), "dd/MM/yyyy");
		if (dobDate1.isAfter(LocalDate.now())) {
			throw new ValidationException(true, MessageUtility.getMessage("RequestFutureDate").getCode(),
					MessageUtility.getMessage("RequestFutureDate").getMessage());
		}

		validateNomineeAgeForAPI(request,body);

	}
	
	private void validateNomineeAgeForAPI(Request request, Map<String, String> body) throws ValidationException, ServiceException {
		logger.debug(String.format("validateNomineeAgeForAPI(%s)", request.getCustomerId()));
		String pattern = "dd/MM/yyyy";
		if (StringUtils.isEmpty(request.getNomineeDob())) {
			throw new ValidationException(true, MessageUtility.getMessage("nomineeDOBNotBlank").getCode(),
					MessageUtility.getMessage("nomineeDOBNotBlank").getMessage());
		}
		int age = -1;
		try {
			if (!StringUtils.isEmpty(request.getNomineeDob())) {
				age = Utility.calculateAge(request.getNomineeDob(), pattern);
			}
		} catch (Exception ex) {
			throw new ValidationException(true, MessageUtility.getMessage("nomineeDOBFormat").getCode(),
					MessageUtility.getMessage("nomineeDOBFormat").getMessage());
		}

//		if (isNomineeMinor && !StringUtils.isEmpty(dob)) {
//			if(age > 18) {
//				throw new ServiceException(true, MessageUtility.getMessage("nomineeAgeLess18").getCode(),
//						MessageUtility.getMessage("nomineeAgeLess18").getMessage());
//			}
//		}
		// Add validation for relationshipWithGuardian.
		if (!isValidRelationShip(request.getNomineeRelationWithSubscriber())) {
			throw new ValidationException(true,
					MessageUtility.getMessage("nomineeRelationWithSubscriberInValid").getCode(),
					MessageUtility.getMessage("nomineeRelationWithSubscriberInValid").getMessage());
		}
		logger.debug("nomineeAge greater than 18: " + age);
		if (!StringUtils.isEmpty(request.getNomineeDob()) && age > 18) {
			isValidOptionalFieldBody(body);
			if (!ValidationUtility.isEmpty(request.getGuardianName())) {
				throw new ValidationException(true, MessageUtility.getMessage("nomineeAgeMore18").getCode(),
						MessageUtility.getMessage("nomineeAgeMore18").getMessage());
			}
			
			if(!StringUtils.isEmpty(request.getRelationshipWithGuardian())) {
				throw new ValidationException(true, MessageUtility.getMessage("relationShipwithGuardianNotBlankIfnomineemore18").getCode(), 
						MessageUtility.getMessage("relationShipwithGuardianNotBlankIfnomineemore18").getMessage());
			}
			// Add validation for relationshipWithGuardian.
			if(!StringUtils.isEmpty(request.getRelationshipWithGuardian())) {
				if (!isValidRelationShip(request.getRelationshipWithGuardian())) {
					throw new ValidationException(true,
							MessageUtility.getMessage("invalidNomineeGuardianrelationship").getCode(),
							MessageUtility.getMessage("invalidNomineeGuardianrelationship").getMessage());
				}
			}
			if(!StringUtils.isEmpty(request.getGuardianMobileNo())) {
				throw new ValidationException(true, MessageUtility.getMessage("guadianMpbileNoNotBlankIfnomineemore18").getCode(), 
						MessageUtility.getMessage("guadianMpbileNoNotBlankIfnomineemore18").getMessage());
			}
			if(!StringUtils.isEmpty(request.getGuardianEmailId())) {
				throw new ValidationException(true, MessageUtility.getMessage("gaurdianEmailIdNotBlanKifNomineemore18").getCode(), 
						MessageUtility.getMessage("gaurdianEmailIdNotBlanKifNomineemore18").getMessage());
			}
			
		}
		
		
		logger.debug("nomineeAge less than 18: " + age);
		if (!StringUtils.isEmpty(request.getNomineeDob()) && age < 18) {
			isValidOptionalFieldBody(body);
			if (ValidationUtility.isEmpty(request.getGuardianName())) {
				throw new ValidationException(true, MessageUtility.getMessage("nomineeAgeLess18").getCode(),
						MessageUtility.getMessage("nomineeAgeLess18").getMessage());
			}

			try {
				Map<String, List> nomineeDob = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
						.get("gaurdianName");
				StringUtil.validateField("gaurdianName", request.getGuardianName(), nomineeDob.get("regx"),
						nomineeDob.get("errorOnMatch"), nomineeDob.get("msg"), nomineeDob.get("code"));
			} catch (ServiceException e) {
				throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
			}
			if(StringUtils.isEmpty(request.getRelationshipWithGuardian())) {
				throw new ValidationException(true, MessageUtility.getMessage("relationShipwithGuardianNotBlankIfnomineeless18").getCode(), 
						MessageUtility.getMessage("relationShipwithGuardianNotBlankIfnomineeless18").getMessage());
			}
			// Add validation for relationshipWithGuardian.
			if (!isValidRelationShip(request.getRelationshipWithGuardian())) {
				throw new ValidationException(true,
						MessageUtility.getMessage("invalidNomineeGuardianrelationship").getCode(),
						MessageUtility.getMessage("invalidNomineeGuardianrelationship").getMessage());
			}
			if(StringUtils.isEmpty(request.getGuardianMobileNo())) {
				throw new ValidationException(true, MessageUtility.getMessage("guadianMpbileNoNotBlankIfnomineeless18").getCode(), 
						MessageUtility.getMessage("guadianMpbileNoNotBlankIfnomineeless18").getMessage());
			}
			
		}

		// Add validation for relationshipWithGuardian.
//		if(!isValidRelationShip(request.getNomineeRelationWithSubscriber())){
//			throw new ValidationException(true, MessageUtility.getMessage("nomineeRelationWithSubscriberInValid").getCode(), 
//					MessageUtility.getMessage("nomineeRelationWithSubscriberInValid").getMessage());
//		}
//		logger.debug("nominee mobile number" + request.getNomineeMobileNumber());
		if (!StringUtils.isEmpty(request.getNomineeAddress())) {
			try {
				Map<String, List> nomineeDob = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
						.get("nomineeAddress");
				StringUtil.validateField("nomineeAddress", request.getNomineeAddress(),
						nomineeDob.get("regx"), nomineeDob.get("errorOnMatch"), nomineeDob.get("msg"),
						nomineeDob.get("code"));
			} catch (ServiceException e) {
				throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
			}
		}
		if (!StringUtils.isEmpty(request.getNomineeMobileNumber())) {
			logger.debug("nominee mobile number" + request.getNomineeMobileNumber());
			try {
				Map<String, List> nomineeDob = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
						.get("nomineeMobileNo");
				StringUtil.validateField("nomineeMobileNo", request.getNomineeMobileNumber(),
						nomineeDob.get("regx"), nomineeDob.get("errorOnMatch"), nomineeDob.get("msg"),
						nomineeDob.get("code"));
			} catch (ServiceException e) {
				throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
			}
		}

		if (!StringUtils.isEmpty(request.getGuardianMobileNo())) {

			try {
				if (request.getNomineeMobileNumber().startsWith("0")) {
					throw new ValidationException(true, 9026, "Guardian Mobile No is invalid");
				}
				Map<String, List> nomineeDob = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
						.get("guardianMobileNo");
				StringUtil.validateField("guardianMobileNo", request.getGuardianMobileNo(), nomineeDob.get("regx"),
						nomineeDob.get("errorOnMatch"), nomineeDob.get("msg"), nomineeDob.get("code"));
			} catch (ServiceException e) {
				throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
			}
		}

		if (!StringUtils.isEmpty(request.getNomineeEmailId())) {

//			if (request.getNomineeEmailId().length() > 50) {
//				throw new ValidationException(true,9022, "Nominee EmailId must not be more than 50 char");
//			} else {
//			}
			try {
				Map<String, List> nomineeDob = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
						.get("nomineeEmailId");
				StringUtil.validateField("nomineeEmailId", request.getNomineeEmailId(), nomineeDob.get("regx"),
						nomineeDob.get("errorOnMatch"), nomineeDob.get("msg"), nomineeDob.get("code"));
			} catch (ServiceException e) {
				throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
			}
			
		}

		if (!StringUtils.isEmpty(request.getGuardianEmailId())) {
			try {
				Map<String, List> nomineeDob = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
						.get("guardianEmailId");
				StringUtil.validateField("guardianEmailId", request.getGuardianEmailId(), nomineeDob.get("regx"),
						nomineeDob.get("errorOnMatch"), nomineeDob.get("msg"), nomineeDob.get("code"));
			} catch (ServiceException e) {
				throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
			}
		}
		logger.debug("sourceCode " + request.getSourcingCode());
		if (!StringUtils.isEmpty(request.getSourcingCode())) {
			logger.debug("sourceCode " + request.getSourcingCode());
			try {
				Map<String, List> nomineeDob = (Map<String, List>) MessageUtility.getValidationProps("optionalField")
						.get("sourceCode");
				StringUtil.validateField("sourceCode", request.getSourcingCode(), nomineeDob.get("regx"),
						nomineeDob.get("errorOnMatch"), nomineeDob.get("msg"), nomineeDob.get("code"));
			} catch (ServiceException e) {
				throw new ValidationException(true, e.getErrorCode(), e.getLocalizedMessage());
			}
		}

	}
	
	@Override
	public Map<String, Object> createDigital(Request request,Map<String, Object> customerInfo) throws DaoException {
		MessageLogger.debug(logger, String.format("createDigital(%s)", request));
		Map<String, Object> result = new HashMap<>();
		try {
			
			SimpleJdbcInsert jdbcInsert = new SimpleJdbcInsert(jdbcTemplate);
			Map<String, String> custParam = new HashMap<>();
			custParam.put("customerId", request.getCustomerId());
			custParam.put("schemeType", request.getSchemeType());
			custParam.put("isUpdateRequest", (request.getId() == null?"N":"Y"));
			custParam.put("premiumAmt", request.getPremiumAmount());
		//	Map<String, Object> customerInfo = getCustomerInfo(custParam);
		
//			if (customerInfo != null && customerInfo.size() > 0) {
//				String custInfoPriAmt = (String) customerInfo.get("premiumAmount");
//				if (!custInfoPriAmt.equalsIgnoreCase(request.getPremiumAmount())) {
//					throw new DaoException(true, MessageUtility.getMessage("premiumAmountDoesNotMatch").getCode() + "",
//							MessageUtility.getMessage("premiumAmountDoesNotMatch").getMessage());
//				}
//			}
			String id =  getRequestId();
			// If record already created.
			if (request.getId() == null) {
				jdbcInsert.withTableName("PM_REQUESTS");
				
				Map<String, Object> map = new HashMap<>();
				map.put("ID", id);
				map.put("CUSTOMER_NAME", request.getCustomerName());
				map.put("SCHEME", request.getSchemeType());
				map.put("REGISTRATION_BRANCH_CODE", customerInfo.get("branchCode"));
				map.put("MASTER_POLICY_NUMBER", customerInfo.get(Constants.POLICY_NO));
				map.put("CUSTOMER_ID", request.getCustomerId());
				map.put("FATHER_NAME", request.getFatherName());
				map.put("ADDRESS_1", customerInfo.get("address1"));
				map.put("ADDRESS_2", customerInfo.get("address2"));
				map.put("ADDRESS_3", customerInfo.get("address3"));
				map.put("EMAIL_ID", customerInfo.get("email"));
				map.put("PAN", customerInfo.get("pan"));
				// CORRESPONDENCE_ADDRESS_4 // Cross verify this with BA
				// map.put("CORRESPONDENCE_ADDRESS_4", customerInfo.get("address3"));

				map.put("CITY", customerInfo.get("city"));
				map.put("DISTRICT_CODE", request.getDistrict());
				// CORRESPONDENCE_STATE // Cross verify its field name with BA
				map.put("STATE", customerInfo.get("state"));
				map.put("COUNTRY", customerInfo.get("country"));
				map.put("PIN_CODE", customerInfo.get("pin"));

				map.put("GENDER", request.getGender());
				map.put("MOBILE_NUMBER", request.getMobileNo());
				map.put("ANY_DISABILITY", request.getAnyDisability());
				if (!StringUtils.isEmpty(request.getAnyDisability())
						&& request.getAnyDisability().equalsIgnoreCase(Constants.Y_VAL)) {
					map.put("DISABILITY_REMARK", request.getDisabilityRemarks());
				}

				// LocalDate dob = (LocalDate) customerInfo.get("dateofBirth");
				LocalDate dob = LocalDate.parse(customerInfo.get("dateofBirth") + "", dobFormatter);
				map.put("DATE_OF_BIRTH", dob);
				LocalDate dateOfApplication = LocalDate.now();//LocalDate.parse(request.getDateOfApplication() + "", dobFormatter);
				map.put("DATE_OF_APPLICATION", dateOfApplication);

				map.put("PREMIUM_AMOUNT", request.getPremiumAmount());

				// Confirm its value with BA
				map.put("PREMIUM_PERIOD", getPremiumPeriod(custParam));

				map.put("POLICY_YEAR", request.getPolicyYear());

				map.put("ACCOUNT_NUMBER", request.getAccountNo());
				map.put("IFS_CODE", customerInfo.get("ifsCode"));
				// map.put("PAN", request.getPan());
				map.put("BRANCH_CODE", customerInfo.get("branchCode"));
				map.put("BRANCH_NAME", customerInfo.get("branchName"));
				map.put("BRANCH_CATEGORY", customerInfo.get("branchCategory"));
				map.put("DISTRICT_CODE", customerInfo.get("district"));
				
				map.put("KYC_DOCUMENT_TYPE", request.getKycDocumentSubmittedByCustomer());
				map.put("KYC_DOCUMENT_ID", request.getKycIDNumberOfSubscriber());
				map.put("NOMINEE_NAME", request.getNomineeName());
				// Check tis
				map.put("NOMINEE_RELATION", request.getNomineeRelationWithSubscriber());
				// NOMINEE_NAME
				LocalDate nomineeDobDate = LocalDate.parse(request.getNomineeDob(), dobFormatter);
				map.put("NOMINEE_DATE_OF_BIRTH", nomineeDobDate);

				map.put("NOMINEE_ADDRESS", request.getNomineeAddress());
				map.put("NOMINEE_MOBILE_NUMBER", request.getNomineeMobileNumber());
				map.put("NOMINEE_EMAIL_ID", request.getNomineeEmailId());

				map.put("CREATED_BY", request.getCreatedBy());
				map.put("CREATED_ON", LocalDateTime.now());
				map.put("STATUS", "submitted");
				map.put("SOURCING_CODE", request.getSourcingCode());
				map.put("CHANNEL", request.getChannel());
				map.put("IS_REG_FORM_UPLOADED", request.getIsDocumentUploaded());

				map.put("GUARDIAN_NAME", request.getGuardianName());
				map.put("GUARDIAN_EMAIL_ID", request.getGuardianEmailId());
				map.put("GUARDIAN_RELATIONSHIP_WITH_NOMINEE", request.getRelationshipWithGuardian());
				map.put("GUARDIAN_MOBILE_NO", request.getGuardianMobileNo());
				map.put("IS_EMAIL_SENT", Constants.N_VAL);
				map.put("IS_SMS_SENT", Constants.N_VAL);
				map.put("SOURCE", request.getSource());
				map.put("REG_UPLOAD_FILE_ID", request.getUploadDocReferenceNumber());
				jdbcInsert.execute(map);
			}
			//validatePMRequest(request);
			result.put(Constants.MSG, String.format(MessageUtility.getMessage("requestRegistrationDigitalSuccess").getMessage(),
					request.getSchemeType(),request.getCustomerId()));
			result.put(Constants.SUCCESS, Constants.Y_VAL);
			result.put(Constants.ID, id);

		} catch (DataAccessException ex) {
			MessageLogger.error(logger, "Data Access Error: " + ex);
			result.put(Constants.MSG, MessageUtility.getMessage("dataAcessError").getMessage());
			result.put(Constants.SUCCESS, Constants.N_VAL);
			throw new DaoException(true, MessageUtility.getMessage("dataAcessError").getCode() + "",
					MessageUtility.getMessage("dataAcessError").getMessage());
		} catch (Exception ex) {
			MessageLogger.error(logger, "Error while creating registration request: " + ex);
			if (ex instanceof DataAccessException) {
				result.put(Constants.MSG, MessageUtility.getMessage("dataAcessError").getMessage());
				result.put(Constants.SUCCESS, Constants.N_VAL);
				throw new DaoException(true, MessageUtility.getMessage("dataAcessError").getCode() + "",
						MessageUtility.getMessage("dataAcessError").getMessage());
			} else if (ex instanceof DaoException) {
				DaoException doex = (DaoException) ex;
				result.put(Constants.MSG, ex.getLocalizedMessage());
				result.put(Constants.SUCCESS, Constants.N_VAL);
				if(doex.getCode()!=null)
					throw new DaoException(true,doex.getCode(), ex.getLocalizedMessage());
				else {
					throw new DaoException(true,"9191", ex.getLocalizedMessage());
				}
			} else {
				result.put(Constants.MSG, MessageUtility.getMessage("errorRegistrationRequest").getMessage());
				result.put(Constants.SUCCESS, Constants.N_VAL);
				throw new DaoException(true, MessageUtility.getMessage("errorRegistrationRequest").getCode() + "",
						MessageUtility.getMessage("errorRegistrationRequest").getMessage());
			}
		}
		return result;
	}


