@Override
	public List<Map<String, Object>> customerSummaryDetails(Map<String, String> body) throws ServiceException {
		MessageLogger.debug(logger, String.format("customerSummaryDetails()"));

		try {
			return this.pmSchemeDao.customerSummaryDetails(body);
		} catch (DaoException ex) {
			if (ex.getCode() != null && ex.isFormatted())
				throw new ServiceException(true, Integer.parseInt(ex.getCode()), ex.getLocalizedMessage());
			else {
				throw new ServiceException(true, -1, ex.getLocalizedMessage());
			}
		}
	}
	
	
	
	
	@Override
	public List<Map<String, Object>> customerSummaryDetails(Map<String, String> body) throws DaoException {
		MessageLogger.debug(logger, String.format("customerSummaryDetails({response = %s})", body));

		try {
			String customerInfoQuery = this.sqlproperties.getProperty("getNewCustomerInfo");
			String renewalCustomerInfoQuery = this.sqlproperties.getProperty("getRenewalCustomerInfo");
			String getInsureNameByPolicyNumberQuery = this.sqlproperties.getProperty("getInsurerNameByPolicyNumber");

			Map<String, Object> namedParameter = new HashMap<>();
			namedParameter.put(Constant.CUSTOMER_ID, body.get(Constant.CUSTOMER_ID));
			namedParameter.put("scheme", body.get("schemeType"));
			namedParameter.put("policyYear", getPolicyYear());

			List<Map<String, Object>> newCustomerInfo = this.namedParameterJdbcTemplate.queryForList(customerInfoQuery, namedParameter);

			if (newCustomerInfo.isEmpty()) {
				throw new DaoException(true, MessageUtility.getMessage("notRegistered").getCode() + "", String.format(MessageUtility.getMessage("notRegistered").getMessage(), body.get("schemeType")));
			}
			namedParameter.put("masterPolicyNumber", newCustomerInfo.get(0).get("MASTER_POLICY_NUMBER"));

			List<Map<String, Object>> customerDetailsList = new ArrayList<>();

			String insurerName;

			try {
				insurerName = this.namedParameterJdbcTemplate.queryForObject(getInsureNameByPolicyNumberQuery, namedParameter, String.class);
			}
			catch (Exception e) {
				MessageLogger.error(logger, MessageUtility.getMessage("InsurerNotPresentAgainstPolicyNumber").getMessage());
				throw new DaoException(true, MessageUtility.getMessage("InsurerNotPresentAgainstPolicyNumber").getCode() + "",
						String.format(MessageUtility.getMessage("InsurerNotPresentAgainstPolicyNumber").getMessage()));				
			}

			if (newCustomerInfo.get(0).get("IS_RENEWED") == null || !newCustomerInfo.get(0).get("IS_RENEWED").equals("Y")) {
				customerDetailsList = this.namedParameterJdbcTemplate.query(customerInfoQuery, namedParameter, (ResultSet rs, int rowNum) -> {
						Map<String, Object> row = new HashMap<>();
						row.put("schemeType", rs.getString("SCHEME"));
						if (insurerName != null) {
							row.put("insurerName", insurerName);
						}
						row.put(Constant.CUSTOMER_ID, rs.getString("CUSTOMER_ID"));
						row.put("accountNo", rs.getString("ACCOUNT_NUMBER"));
						row.put("premiumAmt", rs.getString("PREMIUM_AMOUNT"));
						if (rs.getTimestamp("AUTHORIZED_ON") != null) {
							row.put("registrationDate", DATE_FORMAT.format(new Date(rs.getTimestamp("AUTHORIZED_ON").getTime())));
						}
						row.put("policyYear", rs.getString("POLICY_YEAR"));

						return row;
				});
			}
			else {
				List<Map<String, Object>> renewalCustomerInfo = this.namedParameterJdbcTemplate.queryForList(renewalCustomerInfoQuery, namedParameter);

				if (!renewalCustomerInfo.isEmpty()) {
					customerDetailsList = this.namedParameterJdbcTemplate.query(renewalCustomerInfoQuery, namedParameter, (ResultSet rs, int rowNum) -> {
						Map<String, Object> row = new HashMap<>();
						row.put("schemeType", rs.getString("SCHEME"));
						if (insurerName != null) {
							row.put("insurerName", insurerName);
						}
						row.put(Constant.CUSTOMER_ID, rs.getString("CUSTOMER_ID"));
						row.put("accountNo", rs.getString("ACCOUNT_NUMBER"));
						row.put("premiumAmt", rs.getString("PREMIUM_AMOUNT"));
						if (rs.getTimestamp("AUTHORIZED_ON") != null) {
							row.put("registrationDate", DATE_FORMAT.format(new Date(rs.getTimestamp("AUTHORIZED_ON").getTime())));
						}
						if (rs.getTimestamp("RENEWED_ON") != null) {
							row.put("renewalDate", DATE_FORMAT.format(new Date(rs.getTimestamp("RENEWED_ON").getTime())));
						}
						row.put("renewalYear", rs.getString("POLICY_YEAR"));

						return row;
					});
				}
			}

			return customerDetailsList;
		} catch (DaoException e) {
			MessageLogger.error(logger, "Error while loading customer details", e);
			if(e.isFormatted()) {
				throw new DaoException(true, e.getCode(), e.getLocalizedMessage());
			} else {
				throw new DaoException(true, e.getLocalizedMessage());
			}
		}
	}


@Override
	public Map<String, Object> closureAPIRequest(Request body) throws ServiceException {
		MessageLogger.debug(logger,String.format("closureAPIRequest()"));
		try {
			if(pmSchemeDao.isRistrictionPeriodStarted())
			{
				throw new ServiceException(true,MessageUtility.getMessage("closureAPIValidationRestriction").getCode(),
						MessageUtility.getMessage("closureAPIValidationRestriction").getMessage());
			}
			return pmSchemeDao.closureAPIRequest(body);
		} catch (DaoException ex) {
			MessageLogger.error(logger, "Error While closureApiRequest: ", ex);
			if (ex.getCode() != null && ex.isFormatted())
				throw new ServiceException(true, Integer.parseInt(ex.getCode()), ex.getLocalizedMessage());
			else {
				throw new ServiceException(true, -1, ex.getLocalizedMessage());
			}
		}

	}


@Override
	public Map<String, Object> closureAPIRequest(Request request) throws DaoException {
		MessageLogger.debug(logger, String.format("closureAPIRequest(customerId= %s)", request));
		try {
			String customerId = null;
			String scheme = null;
			String oResult = null;
			String oStatus = null;
			String oMsg = null;
			Map<String, Object> result = new HashMap<>();
			if (request.getCustomerId() != null) {
				customerId = request.getCustomerId();
			}
			if (request.getSchemeType() != null) {
				scheme = request.getSchemeType();
			}

			String query = this.sqlproperties.getProperty("getCustomerCountAPI");
			Map<String, Object> namedParameters = new HashMap<>();
			namedParameters.put("CUSTOMER_ID", customerId);
			namedParameters.put("scheme", scheme);
			int customerCount = (int) this.namedParameterJdbcTemplate.queryForObject(query, namedParameters,
					Integer.class);
			MessageLogger.debug(logger, String.format("Customer Count : %s", customerCount));
			if (customerCount == 0) {
				throw new DaoException(true, MessageUtility.getMessage("notRegisteredWithScheme").getCode() + "",
						String.format(MessageUtility.getMessage("notRegisteredWithScheme").getMessage(),
								request.getSchemeType()));

			}
			String getRequestIdQuery = this.sqlproperties.getProperty("getPmRequestId");
			int requestId = this.namedParameterJdbcTemplate.queryForObject(getRequestIdQuery, namedParameters,
					Integer.class);
			MessageLogger.debug(logger, String.format("requestId Count : %s", requestId));

			Map<String, Object> res = new HashMap<>();

			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withProcedureName(ProcedureNameEnum.PM_REQUESTS_CLOSURE_AUDIT_SP.getValue())
					.declareParameters(new SqlParameter(Constants.I_USER_ID, Types.VARCHAR),
							new SqlParameter(Constants.I_CLASS, Types.VARCHAR),
							new SqlParameter(Constants.I_METHOD, Types.VARCHAR),
							new SqlParameter(Constants.I_RECORD_ID, Types.VARCHAR),
							new SqlParameter(Constants.I_REMARK, Types.VARCHAR),
							new SqlParameter(Constants.I_IS_FORM_REVIEWED, Types.VARCHAR),
							new SqlOutParameter(Constants.O_STATUS, Types.VARCHAR),
							new SqlOutParameter(Constants.O_RESULT, Types.VARCHAR),
							new SqlOutParameter(Constants.O_MSG, Types.VARCHAR));

			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put(Constants.I_USER_ID, customerId);
			inParamMap.put(Constants.I_CLASS, Constants.PMREQUESTSCLOSURE);
			inParamMap.put(Constants.I_METHOD, Constants.DIGITALCLOSUREVERIFY);
			inParamMap.put(Constants.I_RECORD_ID, requestId);
			inParamMap.put(Constants.I_REMARK, request.getClosureRemark());
			inParamMap.put(Constants.I_IS_FORM_REVIEWED, request.getIsClosureFormReviewed());

			MessageLogger.debug(logger,
					String.format("PM_REQUESTS_CLOSURE_AUDIT_SP input param: (%s) ", inParamMap.toString()));

			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			MessageLogger.debug(logger, String.format("Before Execute PM_REQUESTS_CLOSURE_AUDIT_SP"));
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
			MessageLogger.debug(logger, String.format("After Execution PM_REQUESTS_CLOSURE_AUDIT_SP"));
			oResult = (String) simpleJdbcCallResult.get(Constants.O_RESULT);
			oStatus = (String) simpleJdbcCallResult.get(Constants.O_STATUS);
			oMsg = (String) simpleJdbcCallResult.get(Constants.O_MSG);
			MessageLogger.debug(logger, String.format("PM_REQUESTS_CLOSURE_AUDIT_SP(oResult=%s, oStatus=%s, oMsg=%s)",
					oResult, oStatus, oMsg));
//			if ((!StringUtils.isEmpty(oStatus)) && !oStatus.equalsIgnoreCase("0")) {
//				throw new DaoException(true, 9191 + "", oMsg);
//			}
			String requestIdStr = String.valueOf(requestId);
			String MessageString = "Your "+scheme+" scheme account has already been closed";
			if(!oResult.equalsIgnoreCase(MessageString)) {
				getPmRequestClosureDetails(requestIdStr);				
			}
			result.put("RESULT", oResult);
			result.put("Status", oStatus);
			result.put("msg", oMsg);
			return result;

		} catch (DaoException ex) {
			MessageLogger.error(logger, String.format("Error while call PM_REQUESTS_CLOSURE_AUDIT_SP : " + ex));
			if(ex.isFormatted()) {
				throw new DaoException(true, ex.getCode(), ex.getLocalizedMessage());
			} else {
				throw new DaoException(true, MessageUtility.getMessage("errorClosureRequest").getCode() + "",
						MessageUtility.getMessage("errorClosureRequest").getMessage());
			}
		}
	}




	@Override
	public Map<String, Object> getIsRenewalPeriodStarted() throws ValidationException{
		MessageLogger.debug(logger,String.format("getIsRenewalPeriodStarted()"));
		try {
			return pmSchemeDao.getIsRenewalPeriodStarted();
		} catch (Exception ex) {
			MessageLogger.error(logger, "Error While getIsRenewalPeriodStarted: ", ex);
			throw new ValidationException(true, -1, ex.getLocalizedMessage());
		}

	}



@Override
	public Map<String, Object> getIsRenewalPeriodStarted() throws DaoException {
		MessageLogger.debug(logger, "isRistrictionPeriodStarted()");
		try {
			Map<String, Object> row = null;
			Map<String, Object> namedParameter = new HashMap<>();
			namedParameter.put("registrationNotAllowed", "registrationRestrictionPeriod");

			String getConfigDateQuery = this.sqlproperties.getProperty("getConfigDate");
			List<Map<String, Object>> result = this.namedParameterJdbcTemplate.queryForList(getConfigDateQuery,
					namedParameter);

			if (!result.isEmpty()) {
				row = result.get(0);
				LocalDate fromDate = LocalDate.parse(row.get("CONFIG_FROM_DATE").toString(),
						DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				LocalDate toDate = LocalDate.parse(row.get("CONFIG_TO_DATE").toString(),
						DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				
				DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
				String formattedFromDate = fromDate.format(outputFormatter);
				String formattedToDate = toDate.format(outputFormatter);

				LocalDate currentDate = LocalDate.now();

				MessageLogger.debug(logger, "isRistrictionPeriodStarted()"+row.toString());
				if (currentDate.isAfter(fromDate.minusDays(1)) && currentDate.isBefore(toDate.plusDays(1))) {
					row.put("isRestrictionEnabled", Constants.Y_VAL);
				} else {
					row.put("isRestrictionEnabled", Constants.N_VAL);
					row.put("msg", String.format(MessageUtility.getMessage("accountAlreadyClosedInPolicyYearCustSummary").getMessage(),formattedFromDate, formattedToDate));
				}
			}
			return row;
		} catch (Exception ex) {
			MessageLogger.error(logger, "Error in isRistrictionPeriodStarted()" + ex);
			throw new DaoException(true, "Error in isRistrictionPeriodStarted()");
		}
	}
	
	
	
	@Override
	public Map<String, Object> getCustomerEligibilityDetail(Map<String, String> param) throws ServiceException {
		MessageLogger.debug(logger,String.format("getCustomerEligibilityDetail()"));
		try {
			return pmSchemeDao.getCustomerEligibilityDetail(param,getPolicyYear());
		} catch (DaoException ex) {
			MessageLogger.error(logger, "Error While getCustomerEligibilityDetail: ", ex);
			if (ex.getCode() != null && ex.isFormatted())
				throw new ServiceException(true, Integer.parseInt(ex.getCode()), ex.getLocalizedMessage());
			else {
				throw new ServiceException(true, -1, ex.getLocalizedMessage());
			}
		}

	}



@Override
	public Map<String, Object> getCustomerEligibilityDetail(Map<String, String> param, String policyyear)
			throws DaoException {
		MessageLogger.debug(logger, String.format("getCustomerEligibilityDetail(param= %s)", param));

		Map<String, Object> response = new HashMap<>();
		try {
			Request request = new Request();
			request.setCustomerId(param.get("customerId") + "");
			request.setSchemeType(param.get("schemeType") + "");
			Map<String, Object> resultMap = bankService.getCustomerInfo(param, serviceProperties);
			LocalDate dobDate = (LocalDate) resultMap.get("dateofBirth");
			String dob = dobDate.format(dobFormatter);
			resultMap.put("dateofBirth", dob);
			request.setDob(dob);
			String getNextWorkingDate = null;
			LocalDate currentDate = null;
			Map<String, Object> schemeDetails = null;
			Map<String, String> dobDetails = new HashMap<>();
			LocalDate initialDate = LocalDate.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Constants.INDIAN_DATE_PATTERN);
			String currentDateStr = initialDate.format(formatter);
			getNextWorkingDate = getNextWorkingDay(currentDateStr);
			dobDetails.put(Constant.DATE, getNextWorkingDate);
			currentDate = LocalDate.parse(getNextWorkingDate, formatter);
			schemeDetails = getSchemeDetails(currentDate, param);
			if (isEodStarted()) {	
				isValidAge(request, schemeDetails, dobDetails);
			} else if(isHoliday()) {
				isValidAge(request, schemeDetails, dobDetails);
			} else {	
				Map<String, Object> schemeDetails1 = null;
				if(param.get("schemeType").equalsIgnoreCase(SchemeEnum.PMJJBY.getSchemeName())) {
					String startMonth = Month.of(getCurrentPeriod().getFromMonth()).name();
					String endMonth = Month.of(getCurrentPeriod().getToMonth()).name();
					schemeDetails1 = getSchemeDetails(param.get("schemeType") + "", startMonth, endMonth);
					if (schemeDetails1 == null) {
						throw new DaoException(true, MessageUtility.getMessage("schemeDetailNotFound").getCode() + "", String
								.format(MessageUtility.getMessage("schemeDetailNotFound").getMessage(), startMonth, endMonth));
					}
				}
				else {
					String startMonth = Month.of(6).name();
					String endMonth = Month.of(5).name();
					schemeDetails1 = getSchemeDetails(param.get("schemeType") + "", startMonth, endMonth);
					if (schemeDetails1 == null) {
						throw new DaoException(true, MessageUtility.getMessage("schemeDetailNotFound").getCode() + "", String
								.format(MessageUtility.getMessage("schemeDetailNotFound").getMessage(), startMonth, endMonth));
					}
					
				}

				resultMap.put("premiumAmount", String.valueOf(schemeDetails.get("PREMIUM_AMOUNT")));
				if(isAccountClosedInPolicyYear(request)) {
					MessageLogger.debug(logger, "isAccountClosedInPolicyYear > true");
					throw new DaoException(true, MessageUtility.getMessage("accountAlreadyClosedInPolicyYearCustEligibilty").getCode() + "",
							String.format(MessageUtility.getMessage("accountAlreadyClosedInPolicyYearCustEligibilty").getMessage()));
				}
				String query = this.sqlproperties.getProperty("IsCustomerRequestExist");
				Map<String, String> param1 = new HashMap<>();
				param1.put("customerId", param.get("customerId"));
				param1.put("schemeType", param.get("schemeType"));

				int count = this.namedParameterJdbcTemplate.queryForObject(query, param1, Integer.class);
				if (count > 0) {
					dedupeRegistrationCheck(request);
				} else {
					response.put(Constant.IS_EXISTING_CUSTOMER, Constant.N_VAL);
					param.put(Constants.VALID_CUSOTOMER_TYPE,
							MessageUtility.getMessage(Constants.VALID_CUSOTOMER_TYPE).getMessage());
					if (!IsValidCustType(param, serviceProperties)) {
						throw new DaoException(true, MessageUtility.getMessage("invalidCustomerType").getCode() + "",
								String.format(MessageUtility.getMessage("invalidCustomerType").getMessage(),
										param.get("schemeType")));
					} else {
						isValidAge(request, schemeDetails1);
						Map<String, String> resultItem = new HashMap<>();
						resultItem.put("scheme", param.get("schemeType"));
						resultItem.put("customerId", param.get("customerId"));
						resultItem.put("premiumAmt", (String) resultMap.get("premiumAmount"));
						resultItem.put("policyYear", policyyear);
						response.put(Constant.MSG, MessageUtility.getMessage("eligibleForNewSubscriber").getMessage());
						response.put(Constant.IS_EXISTING_CUSTOMER, Constant.N_VAL);
						response.put(Constant.RESULT, Arrays.asList(resultItem));
						return response;
					}
				}
			}			
		} catch (DaoException ex) {
			MessageLogger.error(logger, "Error while calling getCustomerEligibilityDetail: " + ex);
			throw new DaoException(true, ex.getCode(),ex.getLocalizedMessage());
		} catch (Exception ex) {
			MessageLogger.error(logger, "Error while calling getCustomerEligibilityDetail1: " + ex);
			if (ex instanceof DaoException) {
				throw new DaoException(true, ex.getLocalizedMessage());
			} else {
				throw new DaoException(true, MessageUtility.getMessage("alreadyRegiDone").getCode() + "", String
						.format(MessageUtility.getMessage("alreadyRegiDone").getMessage(), param.get("schemeType")));
			}
		}
		return response;
	}
