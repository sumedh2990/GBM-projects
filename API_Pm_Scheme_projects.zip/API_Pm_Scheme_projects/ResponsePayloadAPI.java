package com.pmscheme.web.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL) 
public class ResponsePayloadAPI {

	Map<String, String> header;
	boolean success;
	String msg;
	int status;
	Object result;
	static String broadcast;
	String title;
	String isExistingCustomer;
	String IsRestrictionEnabled;

	public ResponsePayloadAPI() {

	}

	public ResponsePayloadAPI(String msg) {
		this.success = true;
		this.status = 200;
		this.msg = msg;
		this.result = "";
	}

	public ResponsePayloadAPI(int code, String msg) {
		this.success = false;
		this.status = code;
		this.msg = msg;
		this.result = "";
	}

	public ResponsePayloadAPI(int code, String msg, Object result) {
		this.success = false;
		this.status = code;
		this.msg = msg;
		this.result = result;
	}

	public ResponsePayloadAPI(String msg, Object result) {
		this.success = true;
		this.status = 200;
		this.msg = msg;
		this.result = result;
	}

	public ResponsePayloadAPI(int code, Map<String, String> header, String msg, Object result) {
		this.header = header;
		this.success = true;
		this.status = code;
		this.msg = msg;
		this.result = emptyObjectToNullConvert(result);
	}
	
	public ResponsePayloadAPI(int code, Map<String, String> header, Object object2, Object result, Object object, Object IsRestrictionEnabled) {
		this.header = header;
		this.success = true;
		this.status = code;
		this.msg = (String) object2;
		this.result = emptyObjectToNullConvert(result);
		this.isExistingCustomer = (String) object;
		this.IsRestrictionEnabled = (String) IsRestrictionEnabled;
	}

	public ResponsePayloadAPI(int code,boolean status,Map<String, String> header,String msg, Object result) {
		this.header=header;
		this.success = status;
		this.status = code;
		this.msg = msg;
		this.result = emptyObjectToNullConvert(result);
	}
	
	public Map<String, String> getheader() {
		return header;
	}

	public void setheader(Map<String, String> header) {
		this.header = header;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	public String getBroadcast() {
		return ResponsePayloadAPI.broadcast;
	}

	public void setBroadcast(String broadcast) {
		ResponsePayloadAPI.broadcast = broadcast;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIsExistingCustomer() {
		return isExistingCustomer;
	}

	public void setIsExistingCustomer(String isExistingCustomer) {
		this.isExistingCustomer = isExistingCustomer;
	}
	
	public String getIsRestrictionEnabled() {
		return IsRestrictionEnabled;
	}

	public void setIsRestrictionEnabled(String isRestrictionEnabled) {
		IsRestrictionEnabled = isRestrictionEnabled;
	}

	public String convertObjectToJsonString() throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(this);
	}

	private Object emptyObjectToNullConvert(Object result) {
		if (result != null && result instanceof ArrayList) {
			ArrayList list = (ArrayList) result;
			if (list.size() == 0) {
				return null;
			}
		}
		return result;
	}
}

